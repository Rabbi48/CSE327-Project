var searchData=
[
  ['products_2ephp_0',['Products.php',['../controllers_2_products_8php.html',1,'(Global Namespace)'],['../views_2_products_8php.html',1,'(Global Namespace)']]]
];
