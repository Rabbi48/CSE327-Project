var searchData=
[
  ['logged_0',['logged',['../class_index.html#a43d63ecaabdfec18038b07bf847dd8b3',1,'Index']]]
];
