var searchData=
[
  ['removeanitem_0',['RemoveAnItem',['../class_remove_an_item.html',1,'']]],
  ['representatives_1',['Representatives',['../class_representatives.html',1,'']]],
  ['route_2',['Route',['../class_route.html',1,'']]]
];
