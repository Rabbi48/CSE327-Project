var searchData=
[
  ['index_2ephp_0',['index.php',['../includes_2controllers_2index_8php.html',1,'(Global Namespace)'],['../includes_2views_2index_8php.html',1,'(Global Namespace)'],['../index_8php.html',1,'(Global Namespace)']]]
];
