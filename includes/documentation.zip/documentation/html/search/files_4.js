var searchData=
[
  ['home_2ephp_0',['Home.php',['../controllers_2_home_8php.html',1,'(Global Namespace)'],['../views_2_home_8php.html',1,'(Global Namespace)']]]
];
