var searchData=
[
  ['sales_0',['Sales',['../class_sales.html',1,'']]],
  ['salesanalysis_1',['SalesAnalysis',['../class_sales_analysis.html',1,'']]],
  ['searchmodel_2',['SearchModel',['../class_search_model.html',1,'']]],
  ['shortage_3',['Shortage',['../class_shortage.html',1,'']]]
];
