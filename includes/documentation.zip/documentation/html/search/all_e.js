var searchData=
[
  ['query_0',['query',['../class_database.html#adfea2c9d880cf49c77d338c2664d969e',1,'Database']]]
];
