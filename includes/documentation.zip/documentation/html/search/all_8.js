var searchData=
[
  ['home_0',['Home',['../class_home.html',1,'']]],
  ['home_2ephp_1',['Home.php',['../controllers_2_home_8php.html',1,'(Global Namespace)'],['../views_2_home_8php.html',1,'(Global Namespace)']]]
];
