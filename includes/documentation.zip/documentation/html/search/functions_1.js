var searchData=
[
  ['adddata_0',['addData',['../class_crud_model.html#a30053f9830e4d7be7fce2355e9c5e3ec',1,'CrudModel']]],
  ['addtocart2_1',['addtocart2',['../class_add_to_cart.html#a5edf70477519527ba9eae26c05b44d7d',1,'AddToCart']]],
  ['authentication_2',['authentication',['../class_login_model.html#ac86ab494b24474708283c278df2bd5e2',1,'LoginModel']]]
];
