var searchData=
[
  ['geteid_0',['getEid',['../class_crud_model.html#ae21fa597678c1a01957a134490342221',1,'CrudModel']]],
  ['getitems_1',['getItems',['../class_database.html#a269e4d7b49decbecf6a92d4e77c0881c',1,'Database']]]
];
