var searchData=
[
  ['database_0',['Database',['../class_database.html',1,'']]],
  ['deletecomplete_1',['DeleteComplete',['../class_delete_complete.html',1,'']]],
  ['deleterepresentatives_2',['DeleteRepresentatives',['../class_delete_representatives.html',1,'']]]
];
