var searchData=
[
  ['newquantity_0',['newQuantity',['../class_add_to_cart.html#a1a38d17d3d1ca7b60a17a7889c7de6d4',1,'AddToCart']]]
];
