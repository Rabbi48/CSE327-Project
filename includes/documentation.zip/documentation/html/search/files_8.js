var searchData=
[
  ['removeanitem_2ephp_0',['RemoveAnitem.php',['../_remove_anitem_8php.html',1,'']]],
  ['representatives_2ephp_1',['Representatives.php',['../controllers_2_representatives_8php.html',1,'(Global Namespace)'],['../views_2_representatives_8php.html',1,'(Global Namespace)']]],
  ['route_2ephp_2',['Route.php',['../_route_8php.html',1,'']]],
  ['routes_2ephp_3',['Routes.php',['../_routes_8php.html',1,'']]]
];
